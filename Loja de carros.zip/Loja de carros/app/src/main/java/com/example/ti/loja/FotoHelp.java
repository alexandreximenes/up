package com.example.ti.loja;

public class FotoHelp<T> {

}
